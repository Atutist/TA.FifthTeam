package home.service.sorter;

import home.service.interfaces.Sorter;

public class Selection implements Sorter {
    public void sort(short[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            int max = i;
            for(int j=i+1; j<arr.length; j++) {
                if (arr[max] > arr[j]) {
                    max = j;
                }
            }
            short tmp = arr[max];
            arr[max] = arr[i];
            arr[i] = tmp;

        }
    }

}