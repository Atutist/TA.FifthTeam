package home.service.interfaces;

public interface Sorter {
    void sort(short[] arr);
}
