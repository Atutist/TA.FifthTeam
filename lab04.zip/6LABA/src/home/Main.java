package home;

import home.service.interfaces.Sorter;
import home.service.randomizeArray.RandomizeArray;
import home.service.sorter.Bubble;
import home.service.DataProcessor;
import home.service.sorter.Insertion;
import home.service.formatter.RowFormatter;
import home.service.sorter.Selection;


public class Main {

    public static void main(String[] args) {
        short[] first = new short[1000];
        short[] second = new short[10000];
        short[] third = new short[100000];
        try {
            RandomizeArray arr = new RandomizeArray();
            arr.randomizeArray(first);
            arr.randomizeArray(second);
            arr.randomizeArray(third);

            DataProcessor arrSortI = new DataProcessor(new Selection(), new RowFormatter());
            long startTimer = System.currentTimeMillis();
            String result = arrSortI.sorter(third);
            long endTimer =System.currentTimeMillis();
            System.out.println(endTimer - startTimer);
        }
        catch (NullPointerException | IndexOutOfBoundsException | IllegalArgumentException e) {
            System.out.println("Exception!: " + e.getMessage());
        }
    }
}
