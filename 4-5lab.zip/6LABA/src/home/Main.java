package home;

import home.service.interfaces.Sorter;
import home.service.randomizeArray.AlreadySorted;
import home.service.randomizeArray.RandomizeArray;
import home.service.sorter.*;
import home.service.DataProcessor;
import home.service.formatter.RowFormatter;

import java.util.Arrays;


public class Main {

    public static void main(String[] args) {
        short[] first = new short[100000];
        short[] second = new short[1000000];
        short[] third = new short[100000];
        short[] array = new short[1000000];

        try {
            Quicksort sort = new Quicksort();

            RandomizeArray arr = new RandomizeArray();
            AlreadySorted already = new AlreadySorted();

            arr.randomizeArray(first);
            arr.randomizeArray(second);
            already.randomizeArray(third);
            already.randomizeArray(array);

//            DataProcessor arrSortI = new DataProcessor(new Selection(), new RowFormatter());
//            System.out.println("100k: ");
//            long startTimer = System.currentTimeMillis();
//            sort.sort(first, 0, first.length - 1);
//            long endTimer =System.currentTimeMillis();
//            System.out.println(endTimer - startTimer);
//
//            System.out.println("1m: ");
//            long startTimer1 = System.currentTimeMillis();
//            sort.sort(second, 0, second.length-1);
//            long endTimer1 =System.currentTimeMillis();
//            System.out.println(endTimer1 - startTimer1);
//
//            System.out.println("100k: ");
//            long startTimer2 = System.currentTimeMillis();
//            sort.sort(third, 0, third.length-1);
//            long endTimer2 =System.currentTimeMillis();
//            System.out.println(endTimer2 - startTimer2);
//
//            System.out.println("1m: ");
//            long startTimer3 = System.currentTimeMillis();
//            sort.sort(array, 0, array.length-1);
//            long endTimer3 =System.currentTimeMillis();
//            System.out.println(endTimer3 - startTimer3);

        }
        catch (NullPointerException | IndexOutOfBoundsException | IllegalArgumentException e) {
            System.out.println("Exception!: " + e.getMessage());
        }
    }
}
