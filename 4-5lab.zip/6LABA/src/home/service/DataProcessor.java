package home.service;

import home.service.interfaces.Formatter;
import home.service.interfaces.Sorter;

public class DataProcessor {
    Sorter sorter;
    Formatter formatter;
    public DataProcessor (Sorter sorter, Formatter formatter) {
        this.sorter = sorter;
        this.formatter = formatter;
    }

    public String sorter(short[] arr) {
        sorter.sort(arr);
        return formatter.format(arr);
    }
}
