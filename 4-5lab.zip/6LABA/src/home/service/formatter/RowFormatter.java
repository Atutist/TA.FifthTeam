package home.service.formatter;

import home.service.interfaces.Formatter;

public class RowFormatter implements Formatter {
    public String format(short[] arr) {
        String result = "";
        for (int i = 0; i < arr.length; i++) {
            result += arr[i] + " ";
        }
        return result;
    }
}