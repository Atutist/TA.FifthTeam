package home.service.randomizeArray;

public class AlreadySorted {
    public short[] randomizeArray(short[] arr){
        short a= 0;
        for(int i = 0; i < arr.length; i++){
            arr[i] = a;
            a++;
        }
        return arr;
    }
}
