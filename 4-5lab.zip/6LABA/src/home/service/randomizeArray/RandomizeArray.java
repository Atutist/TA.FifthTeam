package home.service.randomizeArray;

public class RandomizeArray {
    public short[] randomizeArray(short[] arr){
        for(int i = 0; i < arr.length; i++){
            arr[i] = (short) (Math.random()*100);
        }
        return arr;
    }
}
