package home.service.interfaces;

public interface Formatter {
    String format(short[] arr);
}
