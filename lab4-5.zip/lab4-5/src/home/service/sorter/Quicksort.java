package home.service.sorter;

public class Quicksort{
    public void sort(short[] arr, int first, int last) {
        if (first < last){
            int divideIndex = partition(arr, first, last);

            sort(arr, first, divideIndex - 1);

            sort(arr, divideIndex, last);
        }
    }

    private static int partition(short[] arr, int first, int last) {
        int rightIndex = last;
        int leftIndex = first;

        int pivot = arr[first + (last - first) / 2];
        while (leftIndex <= rightIndex) {

            while (arr[leftIndex] < pivot) {
                leftIndex++;
            }

            while (arr[rightIndex] > pivot) {
                rightIndex--;
            }

            if (leftIndex <= rightIndex) {
                swap(arr, rightIndex, leftIndex);
                leftIndex++;
                rightIndex--;
            }
        }
        return leftIndex;
    }

    private static void swap(short[] array, int index1, int index2) {
        short tmp  = array[index1];
        array[index1] = array[index2];
        array[index2] = tmp;
    }

}
